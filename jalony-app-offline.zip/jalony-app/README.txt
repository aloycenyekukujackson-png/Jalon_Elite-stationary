JALONY_ELITE STATIONARY - App ya kupakua / Downloadable app

HOW TO USE / JINSI YA KUTUMIA
1. Fungua index.html kwenye browser (Chrome, Edge au Firefox). Inafanya kazi bila internet kabisa.
2. Ili kuiweka kwenye home screen: hosti folda hii kwenye https (mfano Netlify au GitHub Pages),
   fungua link kwenye simu, kisha bonyeza "Install" au "Add to Home screen".
3. Baada ya kufunguliwa mara moja online, app inaendelea kufanya kazi offline kupitia service worker.

Ujumbe wa SMS unafunguka kwenye app ya SMS ya simu, hauhitaji internet.

NOTES
- index.html ina logo, kadi za malipo na kila kitu ndani yake. Haitegemei CDN wala bundle.
- Service worker inahitaji https au localhost. Kufungua index.html moja kwa moja kutoka kwenye faili pia kunafanya kazi.
